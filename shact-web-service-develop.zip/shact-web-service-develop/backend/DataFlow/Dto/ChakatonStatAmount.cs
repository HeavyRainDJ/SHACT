﻿namespace DataFlow.Dto;

public class ChakatonStatAmount
{
    public string? Name { get; set; }
    public int? Amount { get; set; }
}