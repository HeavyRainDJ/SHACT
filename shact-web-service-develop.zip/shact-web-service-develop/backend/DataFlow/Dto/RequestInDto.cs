﻿namespace DataFlow.Dto;

public class RequestInDto
{
    public int? Id { get; set; }
    public string? Status { get; set; }
}