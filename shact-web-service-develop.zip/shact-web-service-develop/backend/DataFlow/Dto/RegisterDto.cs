﻿namespace DataFlow.Dto;

public class RegisterDto
{
    public string? Name { get; set; }
    public string? Email { get; set; }
    public string? Password { get; set; }
    public string? Organization { get; set; }
    public string? HardSkills { get; set; }
    public string? Links { get; set; }
    // public string? Post { get; set; }
    // public string? City { get; set; }
}